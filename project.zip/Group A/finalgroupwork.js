// define initial water amount
let initialWater = 84
let weight = 150
let dailyRequirement = weight * 0.5
let threshold = dailyRequirement

// Simulate each day's water usage over a week
for (let day = 1; day <= 7; day ++) {
    // Generate random water usage
let waterUsage = Math.floor(Math.random() * 12) +  1
initialWater -= waterUsage;
// Check if the water falls below the threshold
if (initialWater < threshold) {
    console.log(`Day ${day}: Warning! water level is below threshold (${initialWater} oz).`);
} else {
    console.log(`Day ${day}: Water level is ${initialWater} oz.`);
}
}

